# TxMod

**Transcript-resolved interpretation of 3′UTR variants through isoform-specific
epitranscriptomic alteration.**

A genomic variant in a 3′UTR usually falls inside the 3′UTR of *several* transcript
isoforms, and its consequence can differ in each — a variant that destroys an m6A
site in one isoform may be inert in another because the surrounding sequence, or
the 3′UTR itself, is different. Tools that annotate a variant once per gene cannot
express this. TxMod evaluates every **variant × transcript** pair separately.

For each pair it: reconstructs the spliced 3′UTR, predicts the change in m6A
methylation (Δprob) with the iM6A ensemble, scans an RBP motif panel for altered
binding potential, and aggregates those into a stability tendency.

## Install

```bash
pip install txmod                 # core: annotation, sequences, motifs, stability
pip install "txmod[m6a]"          # + TensorFlow, for iM6A prediction
pip install "txmod[fasta]"        # + pyfaidx, for large indexed genomes
pip install "txmod[all]"
```

From a clone:

```bash
git clone <repo-url> && cd txmod
pip install -e ".[dev]"
pytest
```

## Quick start

Everything below runs on the bundled miniature reference in `examples/` in a few
seconds — no genome download, no GPU.

```bash
txmod prepare \
    --variants examples/demo.vcf \
    --gtf      examples/mini_annotation.gtf \
    --genome   examples/mini_genome.fa \
    --out      pairs.tsv \
    --fasta-out pairs.fa
```

```
record_key                                                   transcript_id  gene_name  offset_1based  utr_len
TXA1|GENEA|chr1:1654|REF=C|ALT=A|strand=+|offset=4|len=501    TXA1           GENEA      4              501
TXA2|GENEA|chr1:1654|REF=C|ALT=A|strand=+|offset=4|len=250    TXA2           GENEA      4              250
```

One variant, two isoform contexts, **different 3′UTR lengths** — that is the point
of the tool.

Full pipeline (m6A + RBP layers):

```bash
txmod run \
    --variants variants.vcf --gtf gencode.gtf --genome GRCh38.fa \
    --model-dir /path/to/im6a_models --pwm panel.tsv \
    --out results.tsv --events-out rbp_events.tsv
```

`--model-dir` and `--pwm` are optional: omit either and that layer is skipped, so
you can run the annotation/sequence layer with no deep-learning stack installed.

Build a motif panel systematically from a CISBP-RNA download rather than by hand:

```bash
txmod panel \
    --rbp-information RBP_Information_all_motifs.txt \
    --pwm-dir pwms_all_motifs/ \
    --rbp-list stability_rbps.txt \
    --out panel.tsv
```

Motifs whose PWM file is missing or empty are **reported, not silently dropped**.

## Python API

```python
from txmod import prepare_pairs, load_panel, scan_pair, score_pair

pairs = prepare_pairs("variants.vcf", "gencode.gtf", "GRCh38.fa")
motifs = load_panel("panel.tsv")

for p in pairs:
    events = scan_pair(p.ref_seq, p.mut_seq, motifs)
    if events:
        s = score_pair([{"rbp": e.rbp, "delta_norm": e.delta_norm} for e in events])
        print(p.transcript_id, p.offset_1based, s.tendency)
```

## Inputs

| Input | Format | Notes |
|---|---|---|
| Variants | VCF (`.vcf`/`.vcf.gz`) or TSV/CSV | Substitutions only; column names configurable for tables |
| Annotation | GTF or GFF3 (optionally gzipped) | Needs `exon` **and** `CDS` features to locate the stop codon |
| Genome | FASTA | `pyfaidx` used when available; `chr1`/`1` naming both accepted |
| m6A models | iM6A `.h5` ensemble | Optional; `humanRRACH10000_c{1..5}.h5` |
| RBP panel | PWM table | Optional; from `txmod panel` or your own |

Indels are skipped by design: they change 3′UTR length, so position-matched
REF/MUT comparison of a per-nucleotide track is not meaningful.

## Validation status differs by layer

The three layers do not carry equal evidential weight. Read this before quoting
any output.

| Layer | External validation |
|---|---|
| **m6A (Δprob)** | **Validated at single-base resolution.** Against GLORI measurements: AUROC **0.946** (independent cell line 0.951), enrichment **87.7×** at probability ≥ 0.5 (n = 3,000, p < 1e-300), and predicted probability tracks measured methylation stoichiometry (Spearman ρ = 0.335, n = 52,519). An earlier peak-based evaluation gave AUROC 0.604, but MeRIP peaks (median 181 nt) put 47.6 % of candidate adenosines inside some peak; single-base truth drops that background to 0.53 % and reveals the real discriminative power. |
| **RBP binding** | **Partially validated.** IGF2BP1 binding-alteration events are enriched 1.78× in real ENCODE eCLIP peaks (p = 0.042). Of 22 panel RBPs with eCLIP data, most had too few events to test individually; pooled enrichment excluding the IGF2BP family showed no signal. |
| **Stability direction** | **Not externally validated, and known to be fragile.** The aggregate sign flips between defensible coefficient schemes (69 % predicted-increase under `literature`, p = 3.7e-4; 43 % under `go_bidirectional_zero`, p = 0.24), and predicted direction matched measured tumour expression change in only **41 %** of cases. Exploratory only. |

Quote enrichment values through `enrichment_with_power()` so the site count
travels with the ratio — a 2-site observation can read as "2.1× enriched" while
the Fisher test returns p = 0.23. Enrichments resting on fewer than 20 sites are
flagged `underpowered` and `headline_safe=False`.

## Two things to know before interpreting output

**1. Δprob is read over a window, not at one index.** A substitution can alter
methylation of any adenosine whose motif context it touches. An RRACH is five
nucleotides wide, so the affected methylated adenosine lies within ±2 nt of the
mutation; `probability_change()` scans that window and reports the adenosine that moves
most, along with `scored_A_rel` (−2…+2).

Versions ≤ 0.3.0 read a single index, which covers one motif position and
silently drops the other four. The difference is large: on the COSMIC 3′UTR set
the single-index read gave **2,299 events at a 4.19:1 loss:gain ratio**, the
window read gives **14,274 at 1.15:1** — and the earlier imbalance turned out to
be an artefact of *where the value was read*, not a property of the mutations.
Every result carries `delta_prob_shift0` (the old single-index value) so the two
reads can be compared on the same run.

The track-to-sequence offset itself is measured, not assumed: `calibrate_shift()`
asks which shift places high-probability calls on the adenosine of an RRACH, and
raises rather than guessing when the evidence is ambiguous. `run_all()` calibrates
on your own sequences and falls back to `REGISTRATION_OFFSET` only if there is
too little signal to decide.

**2. `RRACH` is the default motif.** It matches the training definition of the
`humanRRACH10000` ensemble. The broader `DRACH` is available (`motif=DRACH`) but
its six `D=U` pentamers lie outside what the model saw: on the reference dataset
those pentamers produced **181 events, all gains and no losses**, because the
model scores them highly only once a mutation converts them to RRACH. Using
RRACH raises motif enrichment from OR 29.5/43.6 to **73.8/84.9** at a cost of
1.3 % of events.

**3. The stability layer is deprecated.** It is retained for reproducibility but
is not part of the published analysis: the sign of its aggregate result flipped
between two defensible coefficient schemes, and the RBP layer it depends on did
not validate against ENCODE eCLIP (no protein survived multiple-testing
correction). Establishing direction needs measured decay rates (SLAM-seq,
BRIC-seq), not motif inference.

Reference-allele mismatches are surfaced too: if the variant file disagrees with
the genome, affected pairs are dropped with a warning (`--on-mismatch raise` to
fail hard). That almost always means mismatched genome builds.

## Modules

| Module | Role |
|---|---|
| `annotation` | GTF/GFF3 parsing, 3′UTR blocks, genomic ↔ spliced-offset mapping |
| `sequences` | Genome access, spliced 3′UTR, REF/MUT construction |
| `variants` | VCF/table readers, variant × transcript pairing |
| `m6a` | iM6A ensemble, windowed Δprob, shift calibration, RRACH/DRACH, isoform divergence |
| `rbp` | PWM log-odds scoring, binding-alteration calling, panel building |
| `stability` | *(deprecated)* Coefficient schemes, event/pair scores, scheme comparison |
| `pipeline` | `prepare_pairs`, `run_all` orchestration |
| `cli` | `prepare` / `run` / `panel` subcommands |

## Reproducibility

The scoring logic reproduces the published pipeline that produced the original
results, so numbers computed with this package are directly comparable:

- RRACH/DRACH annotation (overlap, disruption, creation): **100 % concordant** on 20,000 records
- Windowed Δprob: reproduces the published v2 event set (14,274 events); `delta_prob_shift0` reproduces the v1 set (2,299) to floating-point precision
- PWM normalised scores: identical to **3×10⁻¹⁶** (floating-point precision)

`pytest` (60 tests) covers minus-strand and multi-exon offset mapping, the
measured registration offset, the ±2 nt window read (including a case the
single-index read misses), RRACH-vs-DRACH defaults, PWM normalisation bounds,
event thresholds, coefficient-scheme disagreement, and the
underpowered-enrichment guard.

For the biological validation of each layer, see *Validation status differs by
layer* above.

## Citation

If you use TxMod, please cite the accompanying manuscript
(*[PLACEHOLDER: citation on acceptance]*).

External resources retain their own terms: iM6A (model weights), CISBP-RNA
(motifs), and COSMIC (variants, licence required — not redistributed here).

## Licence

MIT — see `LICENSE`.

## Matched backgrounds (`txmod.background`)

Three results in the accompanying study changed once the comparison was drawn
against a *matched* background instead of a raw one, and two reversed. Those
comparisons are provided as reusable functions, because the failure mode is
generic: an apparent signal that is really a property of what the cases are made of.

| Function | Guards against | Study finding |
|---|---|---|
| `trinucleotide_rate_model` + `depletion_observed_expected` | sequence composition read as selection | apparent mutation depletion around m6A sites vanished (corrected ratio 1.00-1.01 across thresholds 0.3-0.8, all CIs spanning 1.0) |
| `size_matched_enrichment` | gene size read as biology | apparent cancer-gene enrichment vanished (OR 1.96 to 1.12, 95% CI 0.93-1.35, once adjusted) |
| `within_group_auroc` | group identity read as discrimination | discrimination confirmed positional (0.946 global vs 0.943 within-transcript) |

Each returns the uncorrected and corrected estimate together, so neither can be
reported without the other.

```python
from txmod.background import size_matched_enrichment, within_group_auroc

res = size_matched_enrichment(
    is_member=gene_table.is_CGC,
    has_event=gene_table.has_m6A_event,
    covariates={"log_utr": np.log10(gene_table.total_utr_length),
                "log_mut": np.log10(1 + gene_table.n_mutations),
                "n_tx": gene_table.n_transcripts},
)
res["uncorrected"]["odds_ratio"], res["corrected"]["logistic"]["odds_ratio"], res["verdict"]

auc = within_group_auroc(scores, labels, groups=transcript_ids,
                         n_bootstrap=1000, n_permutations=200)
auc["global_auroc"], auc["within_group_auroc"], auc["permutation_mean"]
```

Reproduction check against the study's own gene-level table: uncorrected odds ratio
1.700 (published 1.70), logistic 0.857 (0.86), propensity-matched 0.856 (0.85),
identical 2x2 counts and the same verdict. Matched-pair count and the
Mantel-Haenszel estimate differ slightly from the published run (869 vs 922 pairs;
0.92 vs 0.99) because caliper matching depends on the random seed and on the
stratification grid; the direction and the conclusion are unaffected.
`within_group_auroc`'s global statistic agrees with `scipy.stats.mannwhitneyu` to
floating-point precision, and its within-group permutation null returns 0.50.
