# Changelog

## 0.9.0

**Breaking: the package is renamed to match the tool.** The tool was renamed Txm6A -> TxMod
in manuscript v32, but the package kept the old name until now.

| | was | is now |
|---|---|---|
| distribution | `txm6a` | `txmod` |
| import | `import txm6a` | `import txmod` |
| CLI | `txm6a run ...` | `txmod run ...` |
| display name | `Txm6A` | `TxMod` |

Submodule names are unchanged, including `txmod.m6a` -- `m6a` there denotes the
modification, not the old tool name.

Capitalisation follows the convention set when the tool was first renamed: the display name
carries mixed case (`TxMod`, used in prose, README and LICENSE), while the distribution,
import path and console command are lowercase per PEP 8 and PyPI practice.

Also corrected: the project description in `pyproject.toml` still read "RBP-binding
perturbation", a leftover from the vocabulary change in 0.8.0; it now reads
"RBP-binding alteration".

No behaviour changes. Verified by installing the archive into a clean virtual environment:
60 tests pass, `txmod --help` resolves, and `import txm6a` fails.

## 0.8.0

**Breaking: three public names retired, to match the vocabulary the manuscript settled on.**

| was | is now |
|---|---|
| `perturbation()` | `probability_change()` |
| `overlaps_drach()` | `overlaps_motif()` |
| `drach_change()` | `motif_change()` |

`motif_change()` additionally takes `motif` (default `RRACH`) instead of hardcoding the
default, and its returned keys are `ref_in_motif` / `mut_in_motif` / `motif_disrupted` /
`motif_created` rather than `*_drach`. The old keys said DRACH while holding RRACH results:
`overlaps_drach` already defaulted to `RRACH` from 0.4.0, so every caller of `drach_change`
was getting RRACH annotation under a DRACH label. The same mismatch was found and fixed in
the annotation script that produced the shipped tables.

`PairResult.drach_disrupted` / `.drach_created` are likewise `.motif_disrupted` /
`.motif_created`.

No behaviour changes: the RRACH regex, the window, the registration offset and every
returned value are unchanged. Renaming only. Verified by the existing 60 tests.

Why `motif_*` rather than `rrach_*`: the function takes the motif as an argument, so a
name that hardcodes one consensus would be wrong the moment a caller passes `DRACH`.

## 0.7.0

### Changed

- `size_matched_enrichment` returns the logistic estimate as the only correction.
  Propensity-score matching and the Mantel-Haenszel estimate are removed. All three
  agreed on the study data (1.12 / 1.11 / 1.11 against an uncorrected 1.96), so
  reporting three added length without adding evidence; the logistic estimate uses
  every gene, whereas matching discarded 15% of cases for want of a control.
- The signature drops `n_strata`, `caliper` and `random_state`, which only fed the
  removed estimators.
- Without `statsmodels` there is now no corrected estimate at all, so the verdict
  is `underpowered` rather than one derived from the removed estimators.

Uncorrected values are unchanged.


## 0.6.0

### Changed

- `trinucleotide_rate_model` and `RateModel` drop the substitution-type dimension.
  The model was resolved by trinucleotide *and* substitution type, but every caller
  immediately summed over substitution types: the quantity the depletion test needs
  is whether a position is mutated, not what it changed to. Rates are now keyed on
  the folded trinucleotide alone (32 categories after strand folding).
- `canonical_context(trinuc)` takes one argument and returns the folded trinucleotide.
  It previously took `(trinuc, alt)` and returned `(trinuc, "REF>ALT")`.
- `trinucleotide_rate_model` accepts `(sequence_id, position0)` pairs; the `alt_base`
  element is no longer required. Callers pass one less column.
- A position mutated in several samples now counts once. This matches what the rate
  estimates: the probability that a position is mutated at all.
- `SUBSTITUTION_TYPES` is removed from the public API.

Numerical results are unchanged -- the depletion scan reproduces every value at
every threshold, since the previous code summed the substitution dimension away
before using it.


## 0.5.0

**Renamed from `isoperturb` to `txm6a`.** Breaking: the import path, the CLI
command and the distribution name all change.

The former name collided on two fronts. `Perturb-seq` is an established
wet-lab method (pooled CRISPR screens read out by single-cell RNA-seq), where
the perturbation is applied by the experimenter; here it is a somatic mutation
already present in a tumour, and the comparison is between matched reference and
mutant sequences. Separately, `IsoPerturb` implied a scope — 3'UTR variant
interpretation in general — wider than what the package does, which is m6A and
motif-level RBP occupancy.

`txm6a` states the scope it has: transcript-resolved (`tx`) m6A. It also avoids
`iM6A` (the prediction model this package calls) and `m6Aiso` (a single-molecule
Nanopore m6A caller, Mol Cell 2025), both of which are distinct work.

Migration is a name substitution:

    import isoperturb          ->  import txm6a
    from isoperturb import ... ->  from txm6a import ...
    isoperturb run ...         ->  txm6a run ...

No function signature, return type or default changed in this release.

## 0.4.0

Corrects how the m6A perturbation is read. Versions <= 0.3.0 sampled the
probability track at a single index, which covers one position of the motif and
silently drops the other four; this release scans the window in which an
affected site can lie.

**Breaking:** `perturbation()` now returns the largest change among adenosines
within +/- 2 nt of the mutation rather than the value at one index. Results
computed with <= 0.3.0 are not comparable to 0.4.0 results unless the new
`delta_prob_shift0` field is used.

- `perturbation()` takes `ref_seq`/`mut_seq`/`window`/`shift` and reports
  `scored_A_rel` (-2..+2), `scored_A_offset_1based`, `n_A_in_window` and
  `delta_prob_shift0` (the old single-index value, kept for comparison). A base
  counts as a candidate if it is `A` in either sequence, so created sites are
  captured alongside destroyed ones.
- `calibrate_shift()` measures the track-to-sequence offset from real sequences
  by asking which shift places high-probability calls on the adenosine of an
  RRACH. It raises rather than guessing when the evidence is ambiguous.
  `run_all()` calibrates on the user's own sequences and falls back to
  `REGISTRATION_OFFSET` only when there is too little signal to decide.
- `RRACH` added and made the default motif for `overlaps_drach` and
  `drach_change`, matching the training definition of the `humanRRACH10000`
  ensemble. `DRACH` remains available via `motif=DRACH`.
- `txm6a.stability` deprecated. It is retained for reproducibility but is
  not part of the published analysis.

Effect on the reference dataset (COSMIC 3'UTR, 1,147,306 variant-transcript
pairs): high-confidence events 2,299 -> 14,274; loss:gain 4.19 -> 1.15, the
earlier imbalance having been an artefact of the read position rather than a
property of the mutations; the new set is a strict superset of the old. Motif
enrichment under RRACH rather than DRACH: OR 29.5/43.6 -> 73.8/84.9, at a cost
of 1.3% of events. The `DRACH`-only pentamers (`D=U`) contributed 181 events,
all gains and no losses, because the model scores them highly only once a
mutation converts them to RRACH.

## 0.3.0

Added `txm6a.background`, providing the matched-background comparisons the
accompanying study relied on. All three exist because an unmatched background
manufactured an apparent signal in the original analysis.

- `canonical_context`, `trinucleotide_rate_model`, `RateModel` -- fit a trinucleotide
  somatic mutation-rate model over a supplied universe, folded onto pyrimidine
  reference.
- `depletion_observed_expected` -- mutation depletion around a set of sites reported
  as a ratio of observed-to-expected ratios, with Poisson confidence intervals and a
  one-sided Poisson test. Returns the raw and corrected values together, since the
  gap between them is the artefact.
- `size_matched_enrichment` -- gene-set enrichment corrected for opportunity
  confounders by logistic regression, propensity-score matching, covariate matching
  and Mantel-Haenszel stratification, with a `verdict` field. Reproduces the study's
  published estimates.
- `within_group_auroc` -- AUROC computed globally and restricted to within-group
  pairs on one comparable scale, with group-level bootstrap and a within-group
  permutation null. Isolates positional discrimination from group-level prevalence.

15 tests added (51 total), including adversarial cases: a pure composition artefact
must correct to no depletion, a pure opportunity artefact must correct to no
enrichment, and a score encoding only group identity must fall to 0.5 within groups.

Fixed in the same release: the no-statsmodels fallback in
`size_matched_enrichment` called `ndarray.ptp()`, removed in NumPy 2.0, so the
documented graceful-degradation path raised AttributeError instead of degrading.
A regression test now exercises that path with statsmodels blocked. `statsmodels`
is declared as the optional extra `stats`.

Scoring, prediction and panel construction are unchanged from 0.2.0.

## 0.2.0

Documentation and interpretation-safety release. **No change to any scoring
computation** — results from 0.1.0 remain bit-identical, and the reproducibility
checks against the published pipeline still hold (DRACH 100 % concordant on
20,000 records; PWM scores identical to 3e-16).

Added
- ``rbp.enrichment_with_power()`` — fold enrichment that always returns the site
  count alongside the ratio, with ``underpowered`` (n < 20) and ``headline_safe``
  flags. Motivated by a real error during development: a 2.10x enrichment resting
  on **2 sites** (Fisher p = 0.23) was quoted as a headline result before the site
  count was checked.
- ``MIN_SITES_FOR_ENRICHMENT`` (20) as the documented threshold.
- Four tests, including the n=2 / 2.1x case and the n=153 / 1.88x case.

Changed
- ``stability`` module now opens with an explicit warning that the layer is
  **exploratory and not externally validated**, recording that the aggregate sign
  flips between defensible coefficient schemes (69 % vs 43 % predicted-increase)
  and that predicted direction matched measured expression change in only 41 % of
  cases. The ``literature`` scheme is described as the least-bad default rather
  than a recommended one, noting that only 6 % of scored events involve an RBP
  with an unambiguous Gene Ontology direction.
- README and package docstring now carry a per-layer validation table: the m6A
  layer is validated at single-base resolution (GLORI: AUROC 0.946, 87.7x
  enrichment at n = 3,000, stoichiometry Spearman rho = 0.335), the RBP layer
  partially (IGF2BP1 1.78x in eCLIP peaks, p = 0.042), the stability layer not at
  all.
- The earlier peak-based AUROC (0.604) is now presented with its cause — MeRIP
  peaks put 47.6 % of candidate adenosines inside a peak, capping the metric —
  rather than as the model's performance.

## 0.1.0

First release.

- Transcript-resolved analysis from standard inputs: VCF/TSV variants + GTF/GFF3
  annotation + genome FASTA. Multi-exon and minus-strand 3'UTRs handled; a variant
  is paired with every isoform whose 3'UTR contains it.
- m6A layer: iM6A ensemble wrapper, Delta-prob at the mutated position with the +1
  registration made explicit, DRACH disruption/creation, isoform divergence.
- RBP layer: PWM log-odds scoring with normalised scores, high-confidence
  binding-alteration calling, and systematic panel construction from a CISBP-RNA
  download (skipped motifs reported).
- Stability layer: three coefficient schemes plus ``compare_schemes()`` so
  directional sensitivity is reported rather than assumed.
- CLI: ``prepare``, ``run``, ``panel``. Optional dependencies for the m6A and
  indexed-FASTA layers, so the core installs without a deep-learning stack.
- Validated against the published pipeline: DRACH annotation 100 % concordant
  (n = 20,000); PWM normalised scores identical to 3e-16.
