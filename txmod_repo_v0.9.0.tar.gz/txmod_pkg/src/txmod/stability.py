"""
txmod.stability
====================

Directional inference: translate predicted RBP binding alterations into a
transcript-stability tendency.

Model
-----
Each RBP is assigned a functional coefficient (``+1`` stabilising, ``-1``
destabilising, ``0`` unassigned). An event score is the signed binding change
weighted by that coefficient, and a variant-transcript pair aggregates its
events::

    S_event = delta_norm * coefficient
    S_pair  = sum(S_event)

.. deprecated:: 0.4.0

   **This layer is retained for reproducibility only and is not part of the
   published analysis.** It was withdrawn from the manuscript because its
   direction could not be established from binding motifs alone.

   The evidence against relying on it, from the reference dataset:

   * the sign of the aggregate result *flipped* between two equally defensible
     coefficient schemes (69% predicted-increase under ``literature``,
     p=3.7e-4; 43% under ``go_bidirectional_zero``, p=0.24);
   * predicted direction agreed with measured tumour expression change in only
     41% of cases -- worse than chance;
   * the upstream RBP layer it depends on did not itself validate: across the
     13 proteins with ENCODE eCLIP data, no enrichment survived
     Benjamini-Hochberg correction (best FXR1, 3.18x, q=0.053).

   Establishing direction requires measured decay rates (SLAM-seq, BRIC-seq,
   actinomycin-D chase), not inference from binding motifs. If you use this
   module anyway, report :func:`compare_schemes` alongside any directional
   claim so the scheme-dependence is visible.

Coefficient schemes -- read this before interpreting output
-----------------------------------------------------------
The sign of ``S_pair`` depends on how coefficients are assigned, and different
defensible schemes can disagree. Three are provided so the choice is explicit and
its effect testable rather than buried:

``literature``
    Curated dominant direction from published function (e.g. IGF2BP1-3 stabilise
    m6A-marked targets; ZFP36/AUF1 destabilise). The least-bad default, and the
    only scheme whose assignments rest on published experiments -- but see the
    warning above: on the reference data only 6% of scored events involve an RBP
    with an unambiguous single direction in the Gene Ontology (17 of 288; 161
    were bidirectional, 110 binding-only), so most assignments are curatorial
    judgements rather than facts the data can arbitrate.
``go_strict``
    Only RBPs with an unambiguous single direction in the Gene Ontology; RBPs
    annotated both ways score 0. Conservative, much smaller n.
``go_bidirectional_zero``
    GO-derived, with bidirectional RBPs excluded.

Because many stability-regulating RBPs act context-dependently, directional
output is hypothesis-generating. :func:`compare_schemes` runs several schemes over
the same events so the sensitivity is reported, not assumed away.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Mapping, Optional, Sequence

import numpy as np

#: Curated dominant direction from published RBP function.
LITERATURE_COEFFICIENTS: Dict[str, int] = {
    # m6A readers / stabilisers
    "IGF2BP1": +1, "IGF2BP2": +1, "IGF2BP3": +1,
    "ELAVL1": +1, "ELAVL2": +1, "ELAVL3": +1, "ELAVL4": +1,
    "CIRBP": +1, "QKI": +1, "RBM47": +1, "YBX1": +1, "YBX3": +1,
    "HNRNPC": +1, "FUS": +1, "TAF15": +1, "RBM24": +1,
    "SYNCRIP": +1, "PABPC1": +1,
    # destabilisers / decay-promoting
    "ZFP36": -1, "ZFP36L1": -1, "ZFP36L2": -1,
    "HNRNPD": -1, "KHSRP": -1,
    "ZC3H12A": -1, "ZC3H12B": -1, "ZC3H12C": -1,
    "RC3H1": -1, "RC3H2": -1,
    "CNOT4": -1, "PUM1": -1, "PUM2": -1, "CPEB3": -1,
    "TIA1": -1, "TIAL1": -1,
}


def coefficients_from_go(
    go_terms_by_rbp: Mapping[str, Iterable[str]],
    bidirectional_as_zero: bool = True,
) -> Dict[str, int]:
    """Derive coefficients from Gene Ontology term membership.

    An RBP annotated to *mRNA stabilization* scores ``+1`` and one annotated to
    *mRNA destabilization* ``-1``. RBPs carrying both are ambiguous: they score
    ``0`` when ``bidirectional_as_zero`` is set, and are otherwise omitted.
    """
    out: Dict[str, int] = {}
    for rbp, terms in go_terms_by_rbp.items():
        joined = " ; ".join(str(t) for t in terms).lower()
        stab = "mrna stabilization" in joined
        destab = "mrna destabilization" in joined
        if stab and destab:
            if bidirectional_as_zero:
                out[rbp] = 0
        elif stab:
            out[rbp] = +1
        elif destab:
            out[rbp] = -1
    return out


def event_score(delta_norm: float, coefficient: int) -> float:
    """Signed stability effect of one binding-alteration event."""
    return float(delta_norm) * int(coefficient)


def tendency_label(score: float) -> str:
    """Map a signed score to a human-readable tendency."""
    if score is None or (isinstance(score, float) and np.isnan(score)):
        return "NA"
    if score > 0:
        return "predicted_stability_increase"
    if score < 0:
        return "predicted_stability_decrease"
    return "ambiguous"


@dataclass
class PairStability:
    """Aggregated stability tendency for one variant-transcript pair."""

    key: str
    s_pair: float
    n_events: int
    n_increase: int
    n_decrease: int

    @property
    def tendency(self) -> str:
        return tendency_label(self.s_pair)


def score_pair(
    events: Sequence[Mapping],
    coefficients: Mapping[str, int] = LITERATURE_COEFFICIENTS,
    key: str = "",
    rbp_field: str = "rbp",
    delta_field: str = "delta_norm",
) -> PairStability:
    """Aggregate binding-alteration events into a pair-level tendency.

    Events whose RBP has no coefficient (or coefficient 0) contribute nothing and
    are excluded from ``n_events``, so the count reflects the informative events.
    """
    scores: List[float] = []
    for e in events:
        rbp = e[rbp_field] if isinstance(e, Mapping) else getattr(e, rbp_field)
        delta = e[delta_field] if isinstance(e, Mapping) else getattr(e, delta_field)
        coef = int(coefficients.get(str(rbp), 0))
        if coef == 0:
            continue
        scores.append(event_score(float(delta), coef))
    arr = np.asarray(scores, dtype=float)
    return PairStability(
        key=key,
        s_pair=float(arr.sum()) if arr.size else 0.0,
        n_events=int(arr.size),
        n_increase=int((arr > 0).sum()),
        n_decrease=int((arr < 0).sum()),
    )


def compare_schemes(
    events_by_pair: Mapping[str, Sequence[Mapping]],
    schemes: Mapping[str, Mapping[str, int]],
    rbp_field: str = "rbp",
    delta_field: str = "delta_norm",
) -> "object":
    """Score every pair under several coefficient schemes and summarise agreement.

    Returns a ``pandas.DataFrame`` with one row per scheme: number of pairs with a
    non-zero score, the increase/decrease split, and a two-sided binomial p-value
    against a 50/50 null. Disagreement between schemes is the signal that a
    directional claim is assumption-dependent.
    """
    import pandas as pd
    from scipy.stats import binomtest

    rows = []
    for name, coefs in schemes.items():
        pos = neg = 0
        for key, events in events_by_pair.items():
            ps = score_pair(events, coefs, key=key,
                            rbp_field=rbp_field, delta_field=delta_field)
            if ps.s_pair > 0:
                pos += 1
            elif ps.s_pair < 0:
                neg += 1
        n = pos + neg
        p = binomtest(pos, n, 0.5).pvalue if n else float("nan")
        rows.append({
            "scheme": name,
            "n_pairs_nonzero": n,
            "n_increase": pos,
            "n_decrease": neg,
            "fraction_increase": (pos / n) if n else float("nan"),
            "binomial_p": p,
        })
    return pd.DataFrame(rows)
